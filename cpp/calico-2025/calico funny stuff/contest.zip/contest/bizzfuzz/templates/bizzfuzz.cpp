#include <iostream>

using namespace std;

/**
 * Return the string containing the word you should say
 * 
 * W1: the second-to-last word said
 * W2: the last word said
 */
string solve(string W1, string W2) {
    // YOUR CODE HERE
    return "";
}

int main() {
    int T;
    cin >> T;
    
    for (int i = 0; i < T; i++) {
        string W1, W2;
        cin >> W1 >> W2;
        cout << solve(W1, W2) << '\n';
    }
}
