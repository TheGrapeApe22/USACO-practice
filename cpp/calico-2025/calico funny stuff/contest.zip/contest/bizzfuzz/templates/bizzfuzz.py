def solve(W1: str, W2: str) -> str:
    """
    Return the string containing the word you should say
 
    W1: the second-to-last word said 
    W2: the last word said
    """
    # YOUR CODE HERE
    return ""


def main():
    T = int(input())
    for _ in range(T):
        W1 = input()
        W2 = input()
        print(solve(W1, W2))

if __name__ == '__main__':
    main()
