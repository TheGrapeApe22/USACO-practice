#include <iostream>

using namespace std;

/**
 * Return the score of S amplified K times
 * 
 * S: string to amplify
 * K: integer for number of times to amplify
 */

int solve(string S, int K) {
    // YOUR CODE HERE
    return -1;
}

int main() {
    int T;
    cin >> T;
    for (int i = 0; i < T; i++) {
        int K;
        string S;
        cin >> S >> K;
        cout << solve(S, K) << '\n';
    }
}