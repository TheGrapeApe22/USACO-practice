#include <iostream>

using namespace std;

int solve(int l, int n, string k) {
	 
    // L: Length of bag string
    // N: Target depth
    // S: Bag string (characters can be '(', ')', '|', or 'O')
	 
    // YOUR CODE HERE
    return 0;
}

int main() {
	int t; cin >> t;
	for (int i = 0; i < t; i++) {
		int l, n; cin >> l >> n;
		string s; cin >> s;
	    cout << solve(l, n, s) << "\n";
	}
}