#include <iostream>

using namespace std;

/**
 * Return the name of the player (either Big Ben or Oski) that will always win
 * in a game with K turns assuming both players play optimally.
 * 
 * K: the number of turns
 */
string solve(int K) {
    // YOUR CODE HERE
    return "";
}

int main() {
    int T;
    cin >> T;
    for (int i = 0; i < T; i++) {
        int K;
        cin >> K;
        cout << solve(K) << "\n";
    }
}
