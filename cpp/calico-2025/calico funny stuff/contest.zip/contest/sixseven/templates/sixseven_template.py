def solve(K: int) -> str:
    """
    Return the name of the player (either Big Ben or Oski) that will always win
    in a game with K turns assuming both players play optimally.
    
    K: the number of turns
    """
    # YOUR CODE HERE
    return ''


def main():
    T = int(input())
    for _ in range(T):
        K = int(input())
        print(solve(K))


if __name__ == '__main__':
    main()
